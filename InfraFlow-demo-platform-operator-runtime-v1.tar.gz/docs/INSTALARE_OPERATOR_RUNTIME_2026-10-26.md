# Operator runtime privat — etapă controlată

## Scop și limite

- Probe VPS precedente confirmate: autentificare parolă/TOTP, consultare și logout
  prin `infraflow_demo_auth`, fără SA.
- Noul pachet montează runtime-ul în serviciul privat existent pe loopback 4280.
- Nu există rute de login publice, UI, creare de companii sau provisioning.
- `/health/operator` citește contul prin procedură și verifică decriptarea cheii;
  nu consumă TOTP și nu dovedește încă autentificarea prin HTTP.
- `/health/ready` rămâne intenționat 503. ERP-ul pe 4180 nu este repornit.

## Credenziale

Se păstrează cheia existentă root:root 0600, fără regenerare. Instalatorul cere
UUID-ul operatorului și parola SQL EXISTENTĂ `infraflow_demo_auth`, cu confirmare.
Nu cere SA, parola operatorului sau TOTP. Creează exclusiv două fișiere root 0600:
`/etc/infraflow-demo-platform/operator-sql.password` și `operator-id`.

Drop-in-ul nou 30-operator-runtime.conf folosește trei `LoadCredential=`. Datele
nu sunt incluse în argumente sau variabile de mediu. Copiile runtime sunt citite
din `/run/credentials/infraflow-demo-platform.service`, cu validare de fișier
regulat, UID neprivilegiat, mode 0400, un singur link, fără urmărire symlink.

Referință oficială:
[systemd.exec — Credentials](https://www.freedesktop.org/software/systemd/man/latest/systemd.exec.html#Credentials).
Implementarea reală și metadatele pe systemd 255 trebuie confirmate pe VPS.

## Instalare și revenire

1. Transfer și SHA-256, urmate de confirmarea explicită înainte de instalare.
2. Extragere într-un director temporar nou. Nu se rulează npm și nu se atinge ERP.
3. `sudo python3 scripts/linux/install-demo-platform-operator-runtime.py --install-confirmed`
   din pachetul extras (folosește calea absolută dacă directorul curent diferă).
4. Preflight verifică identitatea serviciului și reader health, refuză ținte deja
   existente. Creează release separat `operator-runtime-v1`, cu driverul existent
   al platformei referit prin symlink root-owned; nu folosește dependențele ERP.
5. Verifică SQL/cheie fără TOTP, apoi repornește DOAR infraflow-demo-platform.
6. Confirmă health operator și SQL. Dacă activarea eșuează, elimină doar drop-in-ul
   creat de această invocare și încearcă revenirea la reader-ul anterior.
7. La orice eșec: nu relua automat. Release-ul și credentialele rămân pentru
   diagnostic; nu există ștergere automată sau suprascriere de fișiere existente.

Testele Python locale pe Windows verifică generarea configurației și crearea
exclusivă; O_NOFOLLOW și permisiunile Linux necesită acceptanță VPS. Nu se declară
livrare sau instalare reușită doar pe baza testelor locale.
