'use strict'
// Private runtime assembly only. No HTTP routes or privileged SQL fallback.
const fs=require('node:fs')
const {createOperatorSqlClient}=require('./operator-sql-client')
const {createSqlOperatorStore}=require('./operator-store')
const {createOperatorAuth}=require('./operator-auth')
const DIRECTORY='/run/credentials/infraflow-demo-platform.service'
function validateCredentialStat(stat,uid){
  if(!Number.isInteger(uid)||uid===0||!stat.isFile()||stat.uid!==uid||stat.nlink!==1
    ||(stat.mode&0o777)!==0o400||stat.size<1||stat.size>128)throw Error('operator_credential_invalid')
}
function readCredential(name){
  if(!['operator-key','operator-sql-password','operator-id'].includes(name))throw Error('operator_credential_invalid')
  const fd=fs.openSync(DIRECTORY+'/'+name,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW)
  try{validateCredentialStat(fs.fstatSync(fd),process.getuid());return fs.readFileSync(fd)}finally{fs.closeSync(fd)}
}
function validateMaterial({key,password,id}){
  if(!Buffer.isBuffer(key)||key.length!==32||!Buffer.isBuffer(password)||!Buffer.isBuffer(id)
    ||! /^[\x20-\x7e]{16,128}$/.test(password.toString('ascii'))
    ||password.some(byte=>byte<32||byte>126)
    ||! /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(id.toString('utf8')))
    throw Error('operator_credential_invalid')
}
async function createOperatorRuntime({read=readCredential,createClient=createOperatorSqlClient}={}){
  let key,password,id,client,store,auth
  try{
    key=read('operator-key');password=read('operator-sql-password');id=read('operator-id')
    validateMaterial({key,password,id})
    client=createClient(password.toString('ascii'))
    store=createSqlOperatorStore({operatorId:id.toString('utf8'),key,procedures:true,execute:client.execute})
    const account=await store.readOperator()
    if(!account||!account.enabled)throw Error('operator_runtime_unavailable')
    auth=createOperatorAuth({store})
    let stopping
    return Object.freeze({
      async check(){const current=await store.readOperator();if(!current||!current.enabled)throw Error('operator_runtime_unavailable');return {ok:true,code:'platform_operator_runtime_verified'}},
      login:input=>auth.login(input),authorize:input=>auth.authorize(input),
      shutdown(){return stopping??=(async()=>{auth.shutdown();store.shutdown();await client.shutdown()})()},
    })
  }catch{
    auth?.shutdown();store?.shutdown();if(client)await client.shutdown().catch(()=>{})
    throw Error('operator_runtime_unavailable')
  }finally{key?.fill(0);password?.fill(0);id?.fill(0)}
}
module.exports={createOperatorRuntime,validateCredentialStat,validateMaterial}
