# Proiecția jurnalului de execuție în raportul SQL

Componentă privată demo; versiunea ERP nu se modifică.

## Implementat local

`scripts/linux/tenant-directory-execution-journal.py` introduce un format v2 separat de jurnalul anterior. Manifestul leagă politica directoarelor și dovada identității OS de job, trial, intenție, încercare, generație, revizie, UID și GID.

Proiecția este numai citire: nu autorizează execuție și nu trimite SQL. Acceptă exclusiv cele 17 evenimente complete (cerere și observație pentru fiecare dintre cele opt directoare, apoi finalizare), cu lanț de hash-uri valid și observații conforme politicii. Refuză încercări diferite, jurnale incomplete, observații duplicate și valori în afara uint64. Device/inode sunt transmise ca șiruri zecimale pentru a evita pierderea preciziei în JavaScript.

Tokenul încercării nu este inclus în raportul proiectat. Transportul autorizat trebuie să îl adauge separat.

## Limite și continuare

- Testele portabile verifică proiecția; nu înlocuiesc verificarea nativă a fișierelor și nici un apel SQL real.
- Este necesar un test nativ al noului jurnal, urmat de integrarea cu brokerul executorului.
- Trimiterea raportului trebuie precedată de o înregistrare durabilă separată: jurnalul OS finalizat nu poate fi extins după evenimentul terminal.
- Pierderea răspunsului SQL impune verificare manuală, fără reîncercare sau raport alternativ automat.
- Încercarea pilot din generația 4 este eliberată și nu poate autoriza crearea directoarelor. O execuție reală necesită o încercare nouă și context SQL valid.
- Directoarele comune deja existente necesită un flux explicit de observație; `shared_verified` nu este tratat ca `observed_created`.

Nicio modificare VPS, creare de directoare tenant sau activare nu este efectuată de această componentă locală.
