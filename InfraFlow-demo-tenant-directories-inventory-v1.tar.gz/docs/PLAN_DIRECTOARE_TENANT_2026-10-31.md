# Directoare tenant — politică și inventar înainte de creare

## Etapa OS precedentă confirmată pe VPS

Trial b1100b43-48d0-42fa-8a1d-73b1286f8242, identitate ift_b1100b4348d042fa8a1d73b1286f, UID 992 / GID 983.
Intent 40f385e6-c722-429a-a8fe-46c6119c4834, observed_created în SQL, executor dedicat, job queued revizie 7 / generație 3, fără lease. Jurnal released, 15 evenimente, fără reluare. Trial neactivat.

Aceste rezultate sunt confirmate de utilizator, nu prin conectare automată a agentului la VPS.

## Politică propusă

| Director | Proprietar | Mod |
|---|---|---|
| /var/lib/infraflow-demo-tenants | root:root | 0711 |
| /etc/infraflow-demo-tenants | root:root | 0711 |
| /var/lib/infraflow-demo-tenants/TRIAL | 992:983 | 0700 |
| /etc/infraflow-demo-tenants/TRIAL | root:983 | 0750 |
| storage/TRIAL/data, uploads, logs, tmp | 992:983 | 0700 |

Părinții comuni permit traversare, nu listare pentru alți utilizatori. Tenantul poate scrie datele proprii, nu configurația root. Cheile, parolele și fișierele de configurare nu sunt create în această etapă.

Inventarul refuză symlink-uri și strămoși modificabili de grup/alții. Numai părinții comuni pot exista deja, dacă au proprietar/mod exact. Orice cale tenant existentă cere verificare; nu se adoptă automat.

## Pachet numai de inventar

`probe-demo-tenant-directories.py --inspect-only`, root Linux: revalidează contul prin observatorul root deja instalat, UID/GID 992/983 și jurnalul released exact. Inspectează cele opt căi canonice, afișează numai politica și rezultatele fără tokenuri. Nu creează directoare și nu accesează SQL.

Patru teste de plan/politică au trecut pe Windows și Ubuntu WSL. Proba completă a inventarului cu identitatea reală rămâne pentru VPS: contul pilot nu a fost creat în laboratorul local.

## Următorul pas de implementat

Pasul directoarelor are nevoie de propriul jurnal durabil și de corelarea rezultatului cu dovada OS confirmată. Transportul OS precedent este intenționat limitat la os_identity; nu îl extindem implicit și nu reluăm claim-ul/crearea identității. Nu există încă în acest pachet o comandă de creare sau o migrare SQL. Perioada de 15 zile rămâne nepornită.
